// WARNING
//
// This file has been generated automatically by Visual Studio from the outlets and
// actions declared in your storyboard file.
// Manual changes to this file will not be maintained.
//
using Foundation;
using System;
using System.CodeDom.Compiler;

namespace TipCalc2
{
    [Register ("ViewController")]
    partial class ViewController
    {
        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel AmountLabel { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField AmountText { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel ExcellentLabel { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel PercentageLabel { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel PoorLabel { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UIImageView RestaurantImageView { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel ServiceLabel { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UISlider ServiceSlider { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField TaxAmountText { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel TaxLabel { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField TaxPercentageText { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UISwitch TaxSwitch { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField TipAmountText { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel TipCalcLabel { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel TipLabel { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField TipPercentageText { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UILabel TotalLabel { get; set; }

        [Outlet]
        [GeneratedCode ("iOS Designer", "1.0")]
        UIKit.UITextField TotalText { get; set; }

        void ReleaseDesignerOutlets ()
        {
            if (AmountLabel != null) {
                AmountLabel.Dispose ();
                AmountLabel = null;
            }

            if (AmountText != null) {
                AmountText.Dispose ();
                AmountText = null;
            }

            if (ExcellentLabel != null) {
                ExcellentLabel.Dispose ();
                ExcellentLabel = null;
            }

            if (PercentageLabel != null) {
                PercentageLabel.Dispose ();
                PercentageLabel = null;
            }

            if (PoorLabel != null) {
                PoorLabel.Dispose ();
                PoorLabel = null;
            }

            if (RestaurantImageView != null) {
                RestaurantImageView.Dispose ();
                RestaurantImageView = null;
            }

            if (ServiceLabel != null) {
                ServiceLabel.Dispose ();
                ServiceLabel = null;
            }

            if (ServiceSlider != null) {
                ServiceSlider.Dispose ();
                ServiceSlider = null;
            }

            if (TaxAmountText != null) {
                TaxAmountText.Dispose ();
                TaxAmountText = null;
            }

            if (TaxLabel != null) {
                TaxLabel.Dispose ();
                TaxLabel = null;
            }

            if (TaxPercentageText != null) {
                TaxPercentageText.Dispose ();
                TaxPercentageText = null;
            }

            if (TaxSwitch != null) {
                TaxSwitch.Dispose ();
                TaxSwitch = null;
            }

            if (TipAmountText != null) {
                TipAmountText.Dispose ();
                TipAmountText = null;
            }

            if (TipCalcLabel != null) {
                TipCalcLabel.Dispose ();
                TipCalcLabel = null;
            }

            if (TipLabel != null) {
                TipLabel.Dispose ();
                TipLabel = null;
            }

            if (TipPercentageText != null) {
                TipPercentageText.Dispose ();
                TipPercentageText = null;
            }

            if (TotalLabel != null) {
                TotalLabel.Dispose ();
                TotalLabel = null;
            }

            if (TotalText != null) {
                TotalText.Dispose ();
                TotalText = null;
            }
        }
    }
}